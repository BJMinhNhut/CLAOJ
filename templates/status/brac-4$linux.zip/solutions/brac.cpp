#include <bits/stdc++.h>
#define fu(i, a, b) for (long long i = (a); i <= (b); i++)
#define fd(i, a, b) for (long long i = (a); i >= (b); i--)
using namespace std;
typedef long long ll;
const ll N = 1e5 + 10;
bool check(string a)
{
    ll sum = 0;
    for (char x : a)
    {
        sum += (x == '(') - (x == ')');
        if (sum < 0) return false;
    }
    return sum == 0;
}
void Solve()
{
    string s;
    cin >> s;
    ll n = (ll)s.size();
    if (n % 2 != 0) return void(cout << "NO\n");
    ll open = 0, close = 0;
    for (char x : s)
    {
        open += (x == '(');
        close += (x == ')');
    }
    if (open > n / 2 || close > n / 2) return void(cout << "NO\n");
    ll dem = n / 2 - open;
    fu(i, 0, n - 1)
    {
        if (s[i] == '?')
        {
            if (dem > 0)
            {
                s[i] = '(';
                dem--;
            }
            else
            {
                s[i] = ')';
            }
        }
    }
    cout << (check(s) ? "YES\n" : "NO\n");
}
int main()
{
//    freopen("brac.inp", "r", stdin);
//    freopen("brac.out", "w", stdout);
    ll T;
    cin >> T;
    while (T--)
    {
        Solve();
    }
}
