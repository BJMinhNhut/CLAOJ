#include <bits/stdc++.h>
#define fu(i, a, b) for (long long i = (a); i <= (b); i++)
#define fd(i, a, b) for (long long i = (a); i >= (b); i--)
using namespace std;
typedef long long ll;
const ll N = 1e5 + 10;
bool check(string a)
{
    ll sum = 0;
    for (char x : a)
    {
        sum += (x == '(') - (x == ')');
        if (sum < 0) return false;
    }
    return sum == 0;
}
void Solve()
{
    string s;
    cin >> s;
    ll n = (ll)s.size();
    if (n % 2 != 0) return void(cout << "NO\n"); else return void(cout << "YES\n");
}
int main()
{
//    freopen("brac.inp", "r", stdin);
//    freopen("brac.out", "w", stdout);
    ll T;
    cin >> T;
    while (T--)
    {
        Solve();
    }
}

