#include <bits/stdc++.h>
#define fu(i, a, b) for (long long i = (a); i <= (b); i++)
#define fd(i, a, b) for (long long i = (a); i >= (b); i--)
using namespace std;
typedef long long ll;
const ll N = 1e5 + 10;
vector <vector <bool>> dp;
void Solve()
{
    string s;
    cin >> s;
    ll n = (ll)s.size();
    s = " " + s;
    if (n % 2 != 0) return void(cout << "NO\n");
    dp.assign(n + 10, vector <bool>(n / 2 + 10, 0));
    dp[0][0] = 1;
    fu(i, 0, n - 1) fu(j, 0, n / 2)
    {
        if (!dp[i][j]) continue;
        if (s[i + 1] == '(') dp[i + 1][j + 1] = true;
        if (s[i + 1] == ')' && j > 0) dp[i + 1][j - 1] = true;
        if (s[i + 1] == '?')
        {
            dp[i + 1][j + 1] = true;
            if (j > 0) dp[i + 1][j - 1] = true;
        }
    }
    cout << (dp[n][0] ? "YES\n" : "NO\n");
}
int main()
{
//    freopen("brac.inp", "r", stdin);
//    freopen("brac.out", "w", stdout);
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    ll T;
    cin >> T;
    while (T--)
    {
        Solve();
    }
}

