#include "testlib.h"
#include <bits/stdc++.h>
using namespace std;
string tmp;
vector <string> ds;
char letter[] = {'(', ')', '?'};
void backtrack(int x, int maxL)
{
    if (x == maxL)
    {
        ds.push_back(tmp);
        return;
    }
    for (int i = 0; i < 3; i++)
    {
        tmp.push_back(letter[i]);
        backtrack(x + 1, maxL);
        tmp.pop_back();
    }
}
int main(int argc, char* argv[])
{
    registerGen(argc, argv, 1);
    int startL = opt<int>("startL");
    int goalL = opt<int>("goalL");
    for(int maxL = startL; maxL <= goalL; maxL++)
    {
        backtrack(0, maxL);
    }
    cout << (int)ds.size() << "\n";
    for (int i = 0; i < (int)ds.size(); i++) cout << ds[i] << "\n";
}

