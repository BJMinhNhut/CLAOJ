#include "testlib.h"
#include <bits/stdc++.h>
using namespace std;
const int numSubtask = 3;
int maxQuery[] = {1000, 1000, 1000};
int maxLength[] = {20, 1000, (int)1e5};
int maxSum[] = {1000, 10000, (int)1e6};
int main(int argc, char* argv[])
{
    registerValidation(argc, argv);
    int subtask = stoi(validator.group()) - 1;
    int numQuery = inf.readInt(1, maxQuery[subtask], "numQuery"); inf.readEoln();
    int Sum = 0;
    for (int i = 1; i <= numQuery; i++)
    {
        string x = inf.readString();
        for (char letter : x)
        {
            ensuref(letter == '(' || letter == ')' || letter == '?', "weird letter found");
        }
        int Length = (int)x.size();
        ensuref(Length >= 1 && Length <= maxLength[subtask], "there is a string that is too long");
        Sum += Length;
    }
    ensuref(Sum <= maxSum[subtask], "total length of all strings is too big");
    inf.readEof();
}
