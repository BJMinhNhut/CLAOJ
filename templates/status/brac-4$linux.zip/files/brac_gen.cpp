#include "testlib.h"
#include <bits/stdc++.h>
using namespace std;
int startQ, goalQ, startL, goalL, goalS, numSubstring;
double minMutate, maxMutate, rateHidden;
char letter[] = {'(', ')', '?'};
string brac(int Length, double rateOpen)
{
    string tmp;
    int sum = 0;
    for (int i = 1; i <= Length; i++)
    {
        if (sum == 0)
        {
            tmp.push_back('(');
            sum++;
            continue;
        }
        if (sum == (Length - i + 1))
        {
            tmp.push_back(')');
            sum--;
            continue;
        }
        int rate = rnd.next(100.0), here;
        if (rate < rateOpen) here = 0; else here = 1;
        tmp.push_back(letter[here]);
        sum += (here == 0) - (here == 1);
    }
    if (sum != 0) assert(false);
    return tmp;
}
string hidden_brac(string s, double rateHidden, double rateMutate)
{
    string tmp = s;
    for (int i = 0; i < (int)s.size(); i++)
    {
        double rate = rnd.next(100.0);
        if (rate < rateHidden) tmp[i] = '?';
    }
    for (int i = 0; i < (int)s.size(); i++)
    {
        double rate = rnd.next(100.0);
        if (rate < rateMutate) tmp[i] = letter[rnd.next(3)];
    }
    return tmp;
}
int main(int argc, char* argv[])
{
    registerGen(argc, argv, 1);
    startQ = opt<int>("startQ");
    goalQ = opt<int>("goalQ");
    startL = opt<int>("startL");
    goalL = opt<int>("goalL");
    goalS = opt<int>("goalS");
    numSubstring = opt<int>("numSubstring");
    minMutate = opt<double>("minMutate");
    maxMutate = opt<double>("maxMutate");
    rateHidden = opt<double>("rateHidden");
    int numQuery = rnd.next(startQ, goalQ);
    cout << numQuery << "\n";
    int Sum = goalS;
    double rM[] = {minMutate, maxMutate};
    for (int id = 0; id < numQuery - 1; id++)
    {
        int Length = rnd.next(startL, goalL);
        if (id % 4 == 0) ///1 xau dung ngau nhien
        {
            if (Length % 2 == 1)
            {
                if (Length + 1 > goalL) Length -= 1; else Length += 1;
            }
            cout << hidden_brac(brac(Length, 50.0), rateHidden, rM[id % 2]) << "\n";
        }
        if (id % 4 == 1) ///1 xau dung gom nhieu xau nho
        {
            if (Length % 2 == 1)
            {
                if (Length + 1 > goalL) Length -= 1; else Length += 1;
            }
            vector <int> ds = rnd.partition(rnd.next(min(Length / 2, numSubstring), Length / 2), Length / 2);
            for (int x : ds) cout << hidden_brac(brac(x * 2, 50.0), rateHidden, rM[id % 2]);
            cout << "\n";
        }
        if (id % 4 == 2) ///1 xau dung to
        {
            if (Length % 2 == 1)
            {
                if (Length + 1 > goalL) Length -= 1; else Length += 1;
            }
            cout << hidden_brac(brac(Length, 80.0), rateHidden, rM[id % 2]) << "\n";
        }
        if (id % 4 == 3) ///1 xau ngau nhien
        {
            for (int i = 1; i <= Length; i++) cout << letter[rnd.next(3)];
            cout << "\n";
        }
        Sum -= Length;
    }
    int Length = min(goalL, Sum);
    if (Length % 2 == 1)
    {
        if (Length + 1 > goalL) Length -= 1; else Length += 1;
    }
    cout << hidden_brac(brac(Length, 80.0), rateHidden, rM[(numQuery - 1) % 2]) << "\n";
}
